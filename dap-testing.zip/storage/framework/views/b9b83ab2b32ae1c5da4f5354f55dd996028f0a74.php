<!-- resources/views/karyawan/create.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Tambah Karyawan</h1>
    <form action="<?php echo e(route('karyawan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama_karyawan" required>
        </div>
        <div class="form-group">
            <label for="tgl_lahir">Tanggal Lahir</label>
            <input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" required>
        </div>
        <div class="form-group">
            <label for="kota_lahir">Kota Lahir</label>
            <input type="text" class="form-control" id="kota_lahir" name="kota_lahir" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dap-testing\resources\views/karyawan/create.blade.php ENDPATH**/ ?>