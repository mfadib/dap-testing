<!-- resources/views/karyawan/show.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detail Karyawan</h1>
    <table class="table">
        <tr>
            <th>ID</th>
            <td><?php echo e($karyawan->id_karyawan); ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo e($karyawan->nama_karyawan); ?></td>
        </tr>
        <tr>
            <th>Tanggal Lahir</th>
            <td><?php echo e($karyawan->tgl_lahir); ?></td>
        </tr>
        <tr>
            <th>Kota Lahir</th>
            <td><?php echo e($karyawan->kota_lahir); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-primary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dap-testing\resources\views/karyawan/show.blade.php ENDPATH**/ ?>