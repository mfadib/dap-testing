<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Penjualan;

class PenjualanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Penjualan::create([
            'id_karyawan' => 1,
            'tgl_transaksi' => '2023-01-10',
            'id_barang' => 1,
            'qty' => 10,
        ]);

        Penjualan::create([
            'id_karyawan' => 1,
            'tgl_transaksi' => '2023-02-06',
            'id_barang' => 1,
            'qty' => 20,
        ]);

        Penjualan::create([
            'id_karyawan' => 2,
            'tgl_transaksi' => '2023-02-06',
            'id_barang' => 2,
            'qty' => 10,
        ]);

        Penjualan::create([
            'id_karyawan' => 3,
            'tgl_transaksi' => '2022-01-05',
            'id_barang' => 1,
            'qty' => 10,
        ]);

        Penjualan::create([
            'id_karyawan' => 5,
            'tgl_transaksi' => '2022-10-20',
            'id_barang' => 3,
            'qty' => 20,
        ]);
    }
}
