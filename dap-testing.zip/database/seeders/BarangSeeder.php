<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Barang;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Barang::create([
            'nama_barang' => 'bantal',
            'harga_barang' => 100000,
        ]);

        Barang::create([
            'nama_barang' => 'divan',
            'harga_barang' => 300000,
        ]);

        Barang::create([
            'nama_barang' => 'matrass',
            'harga_barang' => 450000,
        ]);

        Barang::create([
            'nama_barang' => 'guling',
            'harga_barang' => 50000,
        ]);

        Barang::create([
            'nama_barang' => 'matrass protector',
            'harga_barang' => 150000,
        ]);
    }
}
