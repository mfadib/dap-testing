<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Karyawan;

class KaryawanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Karyawan::create([
            'nama_karyawan' => 'dimas',
            'tgl_lahir' => '1997-06-19',
            'kota_lahir' => 'tangerang',
        ]);

        Karyawan::create([
            'nama_karyawan' => 'genta',
            'tgl_lahir' => '1980-01-20',
            'kota_lahir' => 'tangerang',
        ]);

        Karyawan::create([
            'nama_karyawan' => 'rafi',
            'tgl_lahir' => '1998-09-10',
            'kota_lahir' => 'jakarta',
        ]);

        Karyawan::create([
            'nama_karyawan' => 'alvian',
            'tgl_lahir' => '1992-06-10',
            'kota_lahir' => 'medan',
        ]);

        Karyawan::create([
            'nama_karyawan' => 'damar',
            'tgl_lahir' => '1997-06-08',
            'kota_lahir' => 'jakarta',
        ]);
    }
}
