<!-- resources/views/karyawan/show.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Detail Karyawan</h1>
    <table class="table">
        <tr>
            <th>ID</th>
            <td>{{ $karyawan->id_karyawan }}</td>
        </tr>
        <tr>
            <th>Nama</th>
            <td>{{ $karyawan->nama_karyawan }}</td>
        </tr>
        <tr>
            <th>Tanggal Lahir</th>
            <td>{{ $karyawan->tgl_lahir }}</td>
        </tr>
        <tr>
            <th>Kota Lahir</th>
            <td>{{ $karyawan->kota_lahir }}</td>
        </tr>
    </table>
    <a href="{{ route('karyawan.index') }}" class="btn btn-primary">Kembali</a>
</div>
@endsection