<!-- resources/views/karyawan/index.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Karyawan</h1>
    <a href="{{ route('karyawan.create') }}" class="btn btn-primary">Tambah Karyawan</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Kota Lahir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($karyawan as $karyawan)
            <tr>
                <td>{{ $karyawan->id_karyawan }}</td>
                <td>{{ $karyawan->nama_karyawan }}</td>
                <td>{{ $karyawan->tgl_lahir }}</td>
                <td>{{ $karyawan->kota_lahir }}</td>
                <td>
                    <a href="{{ route('karyawan.show', $karyawan->id_karyawan) }}" class="btn btn-info">Detail</a>
                    <a href="{{ route('karyawan.edit', $karyawan->id_karyawan) }}" class="btn btn-warning">Edit</a>
                    <form action="{{ route('karyawan.destroy', $karyawan->id_karyawan) }}" method="POST" style="display: inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection